// Reveal on scroll
  const revealEls = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.15 });
  revealEls.forEach(el => io.observe(el));

  // Enroll form (front-end only demo)
  const form = document.getElementById('enrollForm');
  const status = document.getElementById('formStatus');
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    status.style.display = 'inline';
    form.reset();
    setTimeout(() => { status.style.display = 'none'; }, 4000);
  });

  // Request box (front-end only demo)
  const requestForm = document.getElementById('requestForm');
  const requestStatus = document.getElementById('requestStatus');
  requestForm.addEventListener('submit', function(e) {
    e.preventDefault();
    requestStatus.style.display = 'inline';
    requestForm.reset();
    setTimeout(() => { requestStatus.style.display = 'none'; }, 4000);
  });

  // Splash intro — opening sound + door-style reveal
  const splash = document.getElementById('splash');
  const enterBtn = document.getElementById('enterBtn');
  document.body.style.overflow = 'hidden';

  function playOpenChime() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        const start = now + i * 0.09;
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(0.16, start + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.9);
        osc.connect(gain).connect(ctx.destination);
        osc.start(start);
        osc.stop(start + 0.95);
      });
    } catch (e) { /* audio not available */ }
  }

  enterBtn.addEventListener('click', function() {
    playOpenChime();
    splash.classList.add('opening');
    document.body.style.overflow = '';
    setTimeout(() => { splash.classList.add('hidden'); }, 1200);
  });
